# Sistema
Software de control de inventario para pymes 
Este software esta hecho con laravel 5.6 y mysql 
para que el sistema funcione correctamente debe ejercutarse
npm install
y ejecutar el script para la base de datos

