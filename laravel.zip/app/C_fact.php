<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class C_fact extends Model
{
    //
}
