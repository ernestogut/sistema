<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class D_fact extends Model
{
    //
}
