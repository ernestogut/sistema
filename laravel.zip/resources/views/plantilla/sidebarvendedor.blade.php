<div class="sidebar">
        <nav class="sidebar-nav">
            <ul class="nav">
                <li class="nav-title">
                    Mantenimiento
                </li>

                <li class="nav-item nav-dropdown">
                    <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-basket"></i> Ventas</a>
                    <ul class="nav-dropdown-items">
                        <li  @click="menu=5" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-basket-loaded"></i> Facturación</a>
                        </li>
                        <li  @click="menu=19" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-basket-loaded"></i> Pedidos web</a>
                        </li>
                    </ul>
                </li>
                <li  class="nav-item nav-dropdown">
                    <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-bag"></i> Financiero</a>
                    <ul class="nav-dropdown-items">
                        <li  @click="menu=17" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-notebook"></i> Cierre de caja</a>
                        </li>
                        <li  @click="menu=18" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-notebook"></i> Movimiento de caja</a>
                        </li>
                    </ul>
                </li>
                <li  class="nav-item nav-dropdown">
                    <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-bag"></i> Inventario</a>
                    <ul class="nav-dropdown-items">
                        <li  @click="menu=14" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-notebook"></i> Traspaso almacén</a>
                        </li>
                    </ul>
                </li>
               <li  class="nav-item nav-dropdown">
                    <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-bag"></i> Listos Ya!</a>
                    <ul class="nav-dropdown-items">
                        <li  @click="menu=31" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-notebook"></i> Pedidos</a>
                        </li>
                    </ul>
                </li>
                <li  class="nav-item nav-dropdown">
                    <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-bag"></i> Socios de negocio</a>
                    <ul class="nav-dropdown-items">
                        <li  @click="menu=6" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-notebook"></i> Clientes</a>
                        </li>
                    </ul>
                </li>
                
                 <li class="nav-item nav-dropdown">
                    <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-pie-chart"></i> Reportes</a>
                    <ul class="nav-dropdown-items">
                        <li   @click="menu=10" class="nav-item">
                            <a class="nav-link" href="#"><i class="icon-chart"></i> Reporte Ventas</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- <button class="sidebar-minimizer brand-minimizer" type="button"></button>-->
    </div>
