<?php $__env->startSection('login'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card-group mb-0">
        <div class="card p-4" style="border-radius: 10px; background: #24273F; border-color: #24273F; color: white; -webkit-box-shadow: 10px 10px 9px 6px rgba(0,0,0,0.34); -moz-box-shadow: 10px 10px 9px 6px rgba(0,0,0,0.34); box-shadow: 10px 10px 9px 6px rgba(0,0,0,0.34);">
        <form method="POST" class="form-horizontal was-validated" action="<?php echo e(route('login')); ?>">
             <?php echo e(csrf_field()); ?>

          <div class="card-body">
            <h1>Bienvenido</h1>
            <p class="text-muted">Login de usuario</p>
            <div class="form-group mb-3<?php echo e($errors->has('usuario' ? 'is-invalid' : '')); ?>">
              
            <input type="text" name="usuario" value="<?php echo e(old('usuario')); ?>" id="usuario" class="form-control" style="border-radius: 10px; border-color: #FD3954;" placeholder="Usuario">
              <?php echo $errors->first('usuario','<span class="invalid-feedback">:message</span>'); ?>

            </div>
            <div class="form-group mb-4<?php echo e($errors->has('password' ? 'is-invalid' : '')); ?>">
              
              <input type="password" style="border-radius: 10px; border-color: #FD3954; " name="password" id="password" class="form-control" placeholder="Password">
              <?php echo $errors->first('password','<span class="invalid-feedback">:message</span>'); ?>

            </div>
            <div class="row">
              <div class="col-6">
                <button type="submit" class="btn btn-success">Acceder</button>
              </div>
            </div>
          </div>
        </form>
        </div>
        <div class="card text-white py-5 d-md-down-none" style="width:44%; border-radius: 10px; background: #1E2137; border-color: #1E2137; -webkit-box-shadow: 10px 10px 9px 6px rgba(0,0,0,0.34); -moz-box-shadow: 10px 10px 9px 6px rgba(0,0,0,0.34); box-shadow: 10px 10px 9px 6px rgba(0,0,0,0.34);">
          <div class="card-body text-center">
            <img src="<?php echo e(asset('img/logo-scp.png')); ?>" alt="asdasd" style="width: 40%;">
            <?php $__currentLoopData = $dato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
              <h2><?php echo e($d->nombre); ?></h2>
              <br><?php echo e($d->direccion); ?> - <?php echo e($d->ciudad); ?>, <?php echo e($d->pais); ?><br>Telefono: <?php echo e($d->telefono); ?><br>e-mail: <?php echo e($d->email); ?>


            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.contenido', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistema_scp\resources\views/auth/login.blade.php ENDPATH**/ ?>